# Authentication & Authorization | Part 4

- Integrating APIs
  - Get Exclusive Prime Deals
- API Call Possible Views
  - Handle Success View
  - Handle Failure View
  - Handle Loading View
